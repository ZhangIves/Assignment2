const ProductService = require("../services/ProductService");

const ProductController = {
    addProduct: async (req, res) => {
        try {
            const { name, description, price, quantity, category } = req.body;
            await ProductService.addProduct(name, description, price, quantity, category);
            res.status(201).json({ message: 'Product added successfully' });
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },

    updateProduct: async (req, res) => {
        try {
            const { name, description, price, quantity, category } = req.body;
            const { id } = req.params;
            await ProductService.updateProduct(id, name, description, price, quantity, category);
            res.status(200).json({ message: 'Product updated successfully' });
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },

    deleteProduct: async (req, res) => {
        try {
            const { id } = req.params;
            await ProductService.deleteProduct(id);
            res.status(200).json({ message: 'Product deleted successfully' });
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },

    getProduct: async (req, res) => {
        try {
            const { page, limit } = req.query;
            const data = await ProductService.getProduct(page, limit);
            res.status(200).json(data);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },

    getProductById: async (req, res) => {
        try {
            const { id } = req.params;
            const product = await ProductService.getProductById(id);
            res.status(200).json(product);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }
};

module.exports = ProductController;