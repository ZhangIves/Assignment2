var express = require('express');
const ProductController = require('../controllers/ProductController');
var router = express.Router();

router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.post("/Product", ProductController.addProduct);

router.put("/Product/:id", ProductController.updateProduct);

router.delete("/Product/:id", ProductController.deleteProduct);

router.get("/Product", ProductController.getProduct);

module.exports = router;
