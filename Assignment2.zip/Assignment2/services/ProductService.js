const ProductModel = require("../model/ProductModel");

const ProductService = {
    addProduct: async (name, description, price, quantity, category) => {
        try {
            console.log("Received data:", { name, description, price, quantity, category }); 
            return await ProductModel.create({
                name, description, price, quantity, category
            });
        } catch (err) {
            throw new Error(err.message);
        }
    },

    updateProduct: (_id, name, description, price, quantity, category) => {
        return ProductModel.updateOne({_id}, {
            name, description, price, quantity, category
        });
    },

    deleteProduct: (_id) => {
        return ProductModel.deleteOne({_id});
    },

    getProduct: (page, limit) => {
        return ProductModel.find({}, ["name", "price", "category"])
                           .sort({price: -1})
                           .skip((page - 1) * limit)
                           .limit(limit);
    }
};

module.exports = ProductService;