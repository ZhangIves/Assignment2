const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ProductType = {
    name: String,
    description: String,
    price: Number,
    quantity: Number,
    category: String
};

const ProductSchema = new Schema(ProductType);
const ProductModel = mongoose.model("Product", ProductSchema);

module.exports = ProductModel;